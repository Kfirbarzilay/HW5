#include "compfunc.h"


compfunc::compfunc(const func& t, const func& z)
{
	outer = &t;
	inner = &z;
}

func & compfunc::operator<<(const int& x)
{
	int inner_res = (inner->operator=)=x;
	int outer_res = (outer->operator=)(inner_res);
	fmap_[x] = outer_res;
	return *this;
}

void compfunc::print(ostream& os) const
{

}

int compfunc::operator=(const int&x)
{
	return x;
}
