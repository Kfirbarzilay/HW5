#ifndef _COMPFUNC_H_
#define _COMPFUNC_H_

#include "func.h"
#include "polynom.h"
#include "ratfunc.h"

class compfunc : public func {
public:
	compfunc(const func& ,const func&);
	virtual func & operator<<(const int& x);
	virtual int operator=(const int&);
	virtual void print(ostream& os)const;
protected:
	const func* outer;
	const func* inner;
};


//template<class T, class Z>
//func & compfunc<T, Z>::operator<<(const int& x)
//{
//	int inner_res = inner = x;
//	int outer_res = outer = inner_res;
//	fmap_[x] = outer_res;
//	return *this;
//}


#endif // !_COMPFUNC_H_
